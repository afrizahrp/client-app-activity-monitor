export default {
  MuiLink: {
    styleOverrides: {
      root: {
        textDecorationColor: 'transparent'
      }
    }
  }
}
