export const isFloat = n => {
  return typeof n === 'number' && n % 1 !== 0
}
